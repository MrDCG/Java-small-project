package com.neuedu.maplestory.util;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import com.neuedu.maplestory.constant.Constant;

public class MyFrame extends Frame {

	private static final long serialVersionUID = -6166299996350611001L;
	/**
	 * 暂停线程
	 */
	public boolean pause = false;

	/**
	 * 加载窗口
	 */
	public void loadFrom() {
		this.setSize(Constant.GAME_WIDTH, Constant.GAME_HEIGHT);
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}

		});
		this.setResizable(false);
		this.setTitle("冒险岛");
		this.setLocationRelativeTo(null);
		new MyThread().start();

	}

	/**
	 * 线程
	 * 
	 * @author DCG19
	 *
	 */
	class MyThread extends Thread {
		/**
		 * 重写run方法
		 */
		@Override
		public void run() {
			for (;;) {
				while (pause) {
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				repaint();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * 背景
	 */
	private Image backImg = null;

	/**
	 *   加载图片的方法
	 */
	@Override
	public void update(Graphics g) {
		if (backImg == null) {
			backImg = this.createImage(Constant.GAME_WIDTH, Constant.GAME_HEIGHT);
		}
		Graphics gOff = backImg.getGraphics();
		Color c = gOff.getColor();
		gOff.setColor(Color.white);
		gOff.fillRect(0, 0, Constant.GAME_WIDTH, Constant.GAME_HEIGHT);
		gOff.setColor(c);
		paint(gOff);
		g.drawImage(backImg, 0, 0, null);
	}

}
