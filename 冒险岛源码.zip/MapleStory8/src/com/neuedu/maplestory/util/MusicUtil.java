package com.neuedu.maplestory.util;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;

import com.neuedu.maplestory.constant.Constant;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.*;

/***
 * 音乐播放器类
 * 
 * @author MrDCG
 */
// 继承自线程类Thread
public class MusicUtil extends Thread {
	/**
	 * 播放
	 */
	private Player player;
	/**
	 * 音乐路径
	 */
	private String musicPath;
	/**
	 * 是否循环
	 */
	private boolean loop;

	/**
	 * 构造方法（默认不循环播放）
	 * 
	 * @param musicPath 音乐路径
	 */
	public MusicUtil(String musicPath) {
		this.musicPath = Constant.MUSIC_IMG_PRE + musicPath + ".mp3";
	}

	/**
	 * 构造方法(是否循环)
	 * 
	 * @param musicpath 音乐文件所在路径
	 * @param loop      循环播放
	 */
	public MusicUtil(String musicpath, boolean loop) {
		this(musicpath);
		this.loop = loop;
	}

	/**
	 * 重写run方法
	 */
	@Override
	public void run() {
		super.run();
		try {
			if (loop) {
				while (true) {
					play();
				}
			} else {
				play();
			}
		} catch (FileNotFoundException | JavaLayerException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 播放方法
	 * 
	 * @throws FileNotFoundException 异常
	 * @throws JavaLayerException    异常
	 */
	private void play() throws FileNotFoundException, JavaLayerException {
		BufferedInputStream buffer = new BufferedInputStream(
				MusicUtil.class.getClassLoader().getResourceAsStream(musicPath));
		player = new Player(buffer);
		player.play();
	}
}