package com.neuedu.maplestory.util;
/**
 * 加载游戏中所有的图片
 * @author Minemine
 *
 */

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import com.neuedu.maplestory.constant.Constant;

public final class ImageUtil {
	/**
	 * 存放项目中所有的图片的键值对
	 */
	private static Map<String, Image> imgs = new HashMap<>();
	/**
	 * 静态加载图片
	 */
	static {
		// icon logo 将图片存入map中
		imgs.put("icon", ImageUtil.getImage("icon/1"));
		// hero 站立向左
		for (int i = 0; i < 4; i++) {
			imgs.put("hero_stand_l" + i, ImageUtil.getImage("hero/stand/left/stand1_" + i));
		}

		// hero 站立向右
		for (int i = 0; i < 4; i++) {
			imgs.put("hero_stand_r" + i, ImageUtil.getImage("hero/stand/right/stand1_" + i));
		}

		// hero walk_left
		for (int i = 0; i < 5; i++) {
			imgs.put("hero_walk_l" + i, ImageUtil.getImage("hero/walk/left/walk1_" + i));

		}
		// hero walk_RIGHT
		for (int i = 0; i < 5; i++) {
			imgs.put("hero_walk_r" + i, ImageUtil.getImage("hero/walk/right/walk1_" + i));

		}
		// hero rope
		imgs.put("hero_rope", ImageUtil.getImage("hero/climb/0"));
		// hero ladder
		imgs.put("hero_ladder", ImageUtil.getImage("hero/climb/1"));

		// hero jump
		// right
		imgs.put("hero_jump_r0", ImageUtil.getImage("hero/jump/right/jump_0"));
		// left
		imgs.put("hero_jump_l0", ImageUtil.getImage("hero/jump/left/jump_0"));

		// hero shoot
		// right
		for (int i = 0; i < 4; i++) {
			imgs.put("hero_shoot_r" + i, ImageUtil.getImage("hero/shoot/right/shoot1_" + i));

		}

		// left
		for (int i = 0; i < 4; i++) {
			imgs.put("hero_shoot_l" + i, ImageUtil.getImage("hero/shoot/left/shoot1_" + i));

		}
		// 子弹
		// right
		for (int i = 0; i < 5; i++) {
			imgs.put("bullet_arrow_r" + i, ImageUtil.getImage("bullet/arrow/right/arrow_r" + i));
		}
		// left
		for (int i = 0; i < 5; i++) {
			imgs.put("bullet_arrow_l" + i, ImageUtil.getImage("bullet/arrow/left/arrow_l" + i));
		}

		// skill1
		// left
		for (int i = 0; i < 5; i++) {
			imgs.put("hero_skill1_l" + i, ImageUtil.getImage("skills/skill1/left/skill1_" + i));

		}

		// right
		for (int i = 0; i < 5; i++) {
			imgs.put("hero_skill1_r" + i, ImageUtil.getImage("skills/skill1/right/skill1_" + i));

		}

		// skill2
		// left
		for (int i = 0; i < 6; i++) {
			imgs.put("hero_skill2_l" + i, ImageUtil.getImage("skills/skill2/left/skill2_" + i));

		}

		// right
		for (int i = 0; i < 6; i++) {
			imgs.put("hero_skill2_r" + i, ImageUtil.getImage("skills/skill2/right/skill2_" + i));

		}

		// mob1 stand
		// right
		for (int i = 0; i < 5; i++) {
			imgs.put("mob1_r" + i, ImageUtil.getImage("mob/mob1/stand/right/" + i));

		}
		// left
		for (int i = 0; i < 5; i++) {
			imgs.put("mob1_l" + i, ImageUtil.getImage("mob/mob1/stand/left/" + i));

		}
		// mob1 walk
		// right
		for (int i = 0; i < 5; i++) {
			imgs.put("mob1_walk_r" + i, ImageUtil.getImage("mob/mob1/walk/right/" + i));

		}
		// left
		for (int i = 0; i < 5; i++) {
			imgs.put("mob1_walk_l" + i, ImageUtil.getImage("mob/mob1/walk/left/" + i));

		}

		// mob1 die
		// left
		for (int i = 0; i < 9; i++) {
			imgs.put("mob1_die_l" + i, ImageUtil.getImage("mob/mob1/die/left/" + i));

		}
		// right
		for (int i = 0; i < 9; i++) {
			imgs.put("mob1_die_r" + i, ImageUtil.getImage("mob/mob1/die/right/" + i));

		}

		// Item
		for (int i = 0; i < 5; i++) {
			imgs.put("item_" + i, ImageUtil.getImage("item/" + i));

		}

		// mob1 attack
		// left
		for (int i = 0; i < 21; i++) {
			imgs.put("mob1_attack_l" + i, ImageUtil.getImage("mob/mob1/attack/left/" + i));

		}
		// right
		for (int i = 0; i < 21; i++) {
			imgs.put("mob1_attack_r" + i, ImageUtil.getImage("mob/mob1/attack/right/" + i));

		}

		imgs.put("rope", ImageUtil.getImage("map/things/绳子2"));

		// blood
		imgs.put("blooddiv0", ImageUtil.getImage("mob/blooddiv/blood"));
		imgs.put("blooddiv1", ImageUtil.getImage("mob/blooddiv/blood1"));
		imgs.put("blooddiv2", ImageUtil.getImage("mob/blooddiv/blood2"));
		imgs.put("blooddiv3", ImageUtil.getImage("mob/blooddiv/blood3"));

		// map
		imgs.put("map", ImageUtil.getImage("map/holy_load/森林"));

		// 空中草地1
		imgs.put("grass1", ImageUtil.getImage("map/things/草地1"));
		// 空中草地2
		imgs.put("grass2", ImageUtil.getImage("map/things/草地2"));
		// 空中草地3
		imgs.put("grass3", ImageUtil.getImage("map/things/grass3"));
		// 阶梯+草地
		imgs.put("ladder", ImageUtil.getImage("map/things/ladder"));
		// 状态栏
		// 血量蓝经验
		imgs.put("blood_hero", ImageUtil.getImage("hero/status/2"));
		// 物品栏
		imgs.put("item_hero", ImageUtil.getImage("hero/status/0"));
		// hero skill
		for (int i = 1; i < 17; i++) {
			imgs.put("hero_skill" + (i - 1), ImageUtil.getImage("hero/skill/" + i));
		}
		/**
		 * 蓝色翅膀
		 */
		for (int i = 0; i < 23; i++) {
			imgs.put("hero_skill2" + i, ImageUtil.getImage("hero/skill2/" + i));
		}
		/**
		 * 人物飞行图片
		 */
		imgs.put("fly", ImageUtil.getImage("hero/fly/0"));
		/**
		 * skill1技能图标
		 */
		imgs.put("icon_skill1", ImageUtil.getImage("hero/icon/icon_skill"));
		/**
		 * 回小血图标
		 */
		imgs.put("icon_small_blood", ImageUtil.getImage("hero/icon/回血"));
		/**
		 * 回中血图标
		 */
		imgs.put("icon_mid_blood", ImageUtil.getImage("hero/icon/回中血"));
		/**
		 * 回半血图标
		 */
		imgs.put("icon_half_blood", ImageUtil.getImage("hero/icon/回半血"));
		/**
		 * 回满血图标
		 */
		imgs.put("icon_full_blood", ImageUtil.getImage("hero/icon/回满血"));
		/**
		 * 回蓝图标
		 */
		imgs.put("icon_mp", ImageUtil.getImage("hero/icon/回蓝"));

		/**
		 * mob2 walk
		 */
		// left
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_walk_l" + i, ImageUtil.getImage("mob/mob2/walk/left/" + i));
		}
		// right
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_walk_r" + i, ImageUtil.getImage("mob/mob2/walk/right/" + i));
		}
		/**
		 * mob2 stand
		 */
		// left
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_stand_l" + i, ImageUtil.getImage("mob/mob2/stand/left/" + i));
		}
		// right
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_stand_r" + i, ImageUtil.getImage("mob/mob2/stand/right/" + i));
		}
		/**
		 * mob2 die
		 */
		// left
		for (int i = 0; i < 10; i++) {
			imgs.put("mob2_die_l" + i, ImageUtil.getImage("mob/mob2/die/left/" + i));
		}
		// right
		for (int i = 0; i < 10; i++) {
			imgs.put("mob2_die_r" + i, ImageUtil.getImage("mob/mob2/die/right/" + i));
		}

		/**
		 * mob2 attack
		 */
		// left
		for (int i = 0; i < 20; i++) {
			imgs.put("mob2_attack_l" + i, ImageUtil.getImage("mob/mob2/attack/left/" + i));
		}
		// right
		for (int i = 0; i < 20; i++) {
			imgs.put("mob2_attack_r" + i, ImageUtil.getImage("mob/mob2/attack/right/" + i));
		}
	}

	/**
	 * 根据图片名加载图片的方法
	 * 
	 * @param imgName
	 * @return img对象
	 */
	private static Image getImage(String path) {
		URL u = ImageUtil.class.getClassLoader().getResource(Constant.IMG_PRE + path + ".png");
		BufferedImage img = null;
		try {
			img = ImageIO.read(u);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;

	}

	/**
	 * 从map中取得图片
	 * 
	 * @param key 图片名
	 * @return 图片对象
	 */
	public static Image get(String key) {
		return imgs.get(key);
	}
}
