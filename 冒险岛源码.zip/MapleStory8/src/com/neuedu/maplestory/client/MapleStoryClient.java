package com.neuedu.maplestory.client;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;

import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.entity.Action;
import com.neuedu.maplestory.entity.Arrow;
import com.neuedu.maplestory.entity.Direction;
import com.neuedu.maplestory.entity.Grassland;
import com.neuedu.maplestory.entity.Hero;
import com.neuedu.maplestory.entity.Item;
import com.neuedu.maplestory.entity.Ladder;
import com.neuedu.maplestory.entity.MapLoad;
import com.neuedu.maplestory.entity.Mob;
import com.neuedu.maplestory.entity.Mob1;
import com.neuedu.maplestory.entity.Mob2;
import com.neuedu.maplestory.entity.Rope;
import com.neuedu.maplestory.entity.Skill;
import com.neuedu.maplestory.entity.SkillIcon;
import com.neuedu.maplestory.entity.Status;
import com.neuedu.maplestory.util.ImageUtil;
import com.neuedu.maplestory.util.MusicUtil;
import com.neuedu.maplestory.util.MyFrame;

public class MapleStoryClient extends MyFrame {

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = -203171016399730275L;

	/**
	 * 存物品的
	 */
	public List<Item> items = new ArrayList<>();
	/**
	 * 英雄
	 */
	public Hero hero = new Hero(this);
	/**
	 * 存放弓箭的容器
	 */
	public List<Arrow> arrows = new ArrayList<>();
	/**
	 * 存放怪物的容器
	 */
	public List<Mob> mobs = new ArrayList<>();
	{
		// 怪物数量
		for (int i = 0; i < 10; i++) {
			int random = new Random().nextInt(4);
			int random1 = new Random().nextInt(1700) + 50;
			Mob mob = new Mob1(this, random1, 860, random);
			mobs.add(mob);
		}
		for (int i = 0; i < 5; i++) {
			int random = new Random().nextInt(4);
			int random1 = new Random().nextInt(1700) + 50;
			Mob mob = new Mob2(this, random1, 250, random);
			mobs.add(mob);
		}
	}

	/**
	 * 更新怪物的方法
	 */
	public void mobs() {

		for (int i = 0; i < 3; i++) {
			int random = new Random().nextInt(4);
			int random1 = new Random().nextInt(1700) + 50;
			Mob mob = new Mob1(this, random1, 860, random);
			mobs.add(mob);
		}
	}

	/**
	 * 更新 第二种怪物
	 */
	public void mob2() {
		for (int j = 0; j < 3; j++) {
			int random = new Random().nextInt(4);
			int random1 = new Random().nextInt(1700) + 50;
			Mob mob = new Mob2(this, random1, 250, random);
			mobs.add(mob);
		}
	}

	/**
	 * 地图类
	 */
	public MapLoad mapload = new MapLoad(this, ImageUtil.get("map"));
	/**
	 * 绳子1
	 */
	public Rope rope1 = new Rope(260, 420);
	/**
	 * 绳子2
	 */
	public Rope rope2 = new Rope(660, 420);
	/**
	 * 绳子3
	 */
	public Rope rope3 = new Rope(1060, 420);

	/**
	 * 空中草地1
	 */
	public Grassland grass1 = new Grassland(147, 374, "grass1");
	/**
	 * 空中草地2
	 */
	public Grassland grass2 = new Grassland(602, 374, "grass2");
	/**
	 * 草地3
	 */
	public Grassland grass3 = new Grassland(1387, 640, "grass3");
	/**
	 * 梯子
	 */
	public Ladder ladder = new Ladder(1387, 518, "ladder");

	/**
	 * 状态栏血量
	 */
	public Status blood = new Status(100, 1000, "blood_hero");
	/**
	 * 状态栏 技能物品栏
	 */
	public Status item_hero = new Status(310, 1000, "item_hero");
	/**
	 * 存放大招的集合
	 */
	public List<Skill> skills = new ArrayList<>();

	/**
	 * 大招技能图标
	 */
	public SkillIcon skill1 = new SkillIcon(320, 1010, "icon_skill1");
	/**
	 * 回小血技能图标
	 */
	public SkillIcon skill2 = new SkillIcon(396, 1010, "icon_small_blood");
	/**
	 * 回中血技能图标
	 */
	public SkillIcon skill3 = new SkillIcon(431, 1010, "icon_mid_blood");
	/**
	 * 回半血技能图标
	 */
	public SkillIcon skill4 = new SkillIcon(466, 1010, "icon_half_blood");
	/**
	 * 回满血技能图标
	 */
	public SkillIcon skill5 = new SkillIcon(500, 1010, "icon_full_blood");

	/**
	 * 回蓝瓶技能图标
	 */
	public SkillIcon skill6 = new SkillIcon(396, 1043, "icon_mp");
	/**
	 * 存放小血瓶的集合
	 */
	public List<Item> small_item = new ArrayList<>();
	/**
	 * 存放中血瓶的集合
	 */
	public List<Item> mid_item = new ArrayList<>();

	/**
	 * 存放半血瓶的集合
	 */
	public List<Item> half_item = new ArrayList<>();
	/**
	 * 存放满血瓶的集合
	 */
	public List<Item> full_item = new ArrayList<>();
	/**
	 * 存放蓝血瓶的集合
	 */
	public List<Item> mp_item = new ArrayList<>();

	/**
	 * 重写frame 的paint方法
	 */
	@Override
	public void paint(Graphics g) {
		mapload.draw(g);
		rope1.draw(g);
		rope2.draw(g);
		rope3.draw(g);
		grass1.draw(g);
		grass2.draw(g);
		ladder.draw(g);
		grass3.draw(g);
		blood.draw(g);
		item_hero.draw(g);
		skill1.draw(g);
		skill2.draw(g);
		skill3.draw(g);
		skill4.draw(g);
		skill5.draw(g);
		skill6.draw(g);
		Font f = g.getFont();
		g.setFont(new Font("微软雅黑 ", Font.BOLD, 16));
		g.drawString("" + (9 - hero.time_count * 50 / 1000), 327, 1026);

		g.drawString("" + small_item.size(), 404, 1026);
		g.drawString("" + mid_item.size(), 440, 1026);
		g.drawString("" + half_item.size(), 476, 1026);
		g.drawString("" + full_item.size(), 512, 1026);
		g.drawString("" + mp_item.size(), 404, 1060);
		for (int i = 0; i < arrows.size(); i++) {
			Arrow arrow = arrows.get(i);
			arrow.draw(g);
			arrow.hit(mobs);

		}
		for (int i = 0; i < skills.size(); i++) {
			Skill skill = skills.get(i);
			skill.draw(g);
			skill.hit(mobs);

		}
		int count = 0;
		for (int i = 0; i < mobs.size(); i++) {
			Mob mob = mobs.get(i);
			mob.draw(g);
			if ("幽灵魔法师".equals(mob.name)) {
				count++;
			}

		}
		if (count <= 3) {
			mob2();
		}
		if (mobs.size() <= 5) {
			mobs();
		}
		hero.draw(g);
		Iterator<Item> it = items.iterator();
		// 道具容器
		while (it.hasNext()) {
			Item item = it.next();
			item.draw(g);
		}
		hero.eatItem(items);

		hero.recovery();
		g.drawString("攻击力:" + hero.attackPower, 10, 1050);
		g.drawString("防御力:" + hero.defense, 10, 1070);
		g.setFont(new Font("微软雅黑 ", Font.BOLD, 30));
		g.drawString("LV." + hero.level, 10, 1030);

		g.setFont(f);

		if (hero.die && hero.die_count == 1) {
			hero.die_count++;
			pause = true;
			int res = JOptionPane.showConfirmDialog(null, "角色已死亡，重新开始/退出？", "提示", JOptionPane.YES_NO_OPTION);
			if (res == JOptionPane.YES_OPTION) {
				reset(g);
			} else {
				System.exit(0);
			}
		}
	}

	/**
	 * 重启游戏
	 * 
	 * @param g 画笔
	 */
	public void reset(Graphics g) {
		hero.die = false;
		pause = false;
		hero.HP = 1000;
		hero.MP = 1000;
		hero.level = 0;
		hero.x = 300;
		hero.y = 860;
		hero.speed = Constant.HERO_SPEED;
		hero.dir = Direction.RIGHT;
		hero.img = ImageUtil.get("hero_stand_r0");
		hero.action = Action.STAND;
		hero.HP_FULL = hero.HP;
		hero.MP_FULL = hero.MP;
		hero.EXP = 0;
		hero.attackPower = 10;
		hero.defense = 10;
		items.clear();
		arrows.clear();
		small_item.clear();
		mid_item.clear();
		half_item.clear();
		full_item.clear();
		mp_item.clear();
		paint(g);

	}

	/**
	 * 加载窗口
	 */
	@Override
	public void loadFrom() {
		super.loadFrom();
		this.setIconImage(ImageUtil.get("icon"));
		// 键盘监听
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				hero.keyPressed(e);
				if (e.getKeyCode() == KeyEvent.VK_P) {
					pause = true;
				}
				if (e.getKeyCode() == KeyEvent.VK_O) {
					pause = false;
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				hero.keyReleased(e);
			}
		});
		new MusicUtil("bgm/mapBgm",true).start();
	}

	/**
	 * 主函数
	 * 
	 * @param args 数组
	 */
	public static void main(String[] args) {
		new MapleStoryClient().loadFrom();
	}

}
