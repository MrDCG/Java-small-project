package com.neuedu.maplestory.entity;

import java.awt.Graphics;

import com.neuedu.maplestory.util.ImageUtil;

/**
 * @author MrDCG
 * @version 创建时间：2019年8月24日 下午3:41:26
 *
 */
public class Ladder extends MapleStoryObject {
	/**
	 * 有参构造
	 * 
	 * @param x   横坐标
	 * @param y   纵坐标
	 * @param key 图片名
	 */
	public Ladder(int x, int y, String key) {
		this.x = x;
		this.y = y;
		this.img = ImageUtil.get(key);
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
	}

	/**
	 * 画的方法
	 */
	@Override
	public void draw(Graphics g) {
		g.drawImage(img, x, y, null);
	}

	/**
	 * 移动方法
	 */
	@Override
	public void move() {
		// TODO Auto-generated method stub

	}

}