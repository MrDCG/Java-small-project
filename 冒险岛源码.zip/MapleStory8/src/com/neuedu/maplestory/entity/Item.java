package com.neuedu.maplestory.entity;

import java.awt.Graphics;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;

/**
 * @author MrDCG
 * @version 创建时间：2019年8月21日 上午9:36:32
 *
 */
public class Item extends MapleStoryObject {
	/**
	 * 道具类型
	 */
	public int itemType;

	/**
	 * 空参构造
	 */
	public Item() {

	}

	/**
	 * 有参构造
	 * 
	 * @param msc      调停者
	 * @param x        横坐标
	 * @param y        纵坐标
	 * @param itemType 道具类型
	 */
	public Item(MapleStoryClient msc, int x, int y, int itemType) {
		this.msc = msc;
		this.x = x;
		this.y = y;
		switch (itemType) {
		case 0:
			this.img = ImageUtil.get("item_0");
			break;
		case 1:
			this.img = ImageUtil.get("item_1");
			break;
		case 2:
			this.img = ImageUtil.get("item_2");
			break;
		case 3:
			this.img = ImageUtil.get("item_3");
			break;
		case 4:
			this.img = ImageUtil.get("item_4");
			break;

		default:
			break;
		}
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
		this.itemType = itemType;
	}

	/**
	 * 重写的画的方法
	 */
	@Override
	public void draw(Graphics g) {
		g.drawImage(img, x, y, null);
		move();
	}

	/**
	 * 移动方法
	 */
	@Override
	public void move() {
		if (jump) {
			jump();
		}

	}

	/**
	 * 初速度
	 */
	private double v0 = Constant.HERO_JUMP_SPEED;
	/**
	 * 末速度
	 */
	private double vt = 0;
	/**
	 * 单位位移量
	 */
	private double delta_h = 0;
	/**
	 * 重力加速度
	 */
	private static final double g = 9.8;
	/**
	 * 单位时间
	 */
	private double t = 1;
	/**
	 * 起跳方向
	 */
	private boolean jump_up = true; // 默认向上
	/**
	 * 是否起跳
	 */
	private boolean jump = true;

	/**
	 * 跳的算法
	 */
	public void jump() {
		if (jump_up) {
			// 竖直上抛
			vt = v0 - g * t;
			v0 = vt;
			delta_h = v0 * t;
			y -= delta_h;
			if (vt <= 0) {
				vt = 0;
				v0 = 0;
				jump_up = false; // 进入自由落体
			}
		} else {
			// 自由落体
			vt = v0 + g * t;
			v0 = vt;
			delta_h = v0 * t;
			y += delta_h;
			// 结束自由落体
			if (y > 900) {
				y = 900;
				jump_up = true;
				// 下次竖直上抛的两个速度
				v0 = Constant.HERO_JUMP_SPEED;
				vt = 0;
				jump = false;
			}

		}
	}
}
