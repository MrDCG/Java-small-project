package com.neuedu.maplestory.entity;

/**
 * @author MrDCG
 * @version 创建时间：2019年8月19日 上午10:00:44
 *
 */
public enum Action {
	STAND, WALK, JUMP, SHOOT, DIE, ATTACK, CLIMB, SKILL
}
