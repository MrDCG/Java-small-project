package com.neuedu.maplestory.entity;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import com.neuedu.maplestory.client.MapleStoryClient;

/**
 * 冒险岛游戏中所有类的父类
 * 
 * @author Minemine
 *
 */
public abstract class MapleStoryObject implements Moveable, Drawable {
	/**
	 * x坐标
	 */
	public int x;
	/**
	 * y坐标
	 */
	public int y;
	/**
	 * 图片对象
	 */
	public Image img;
	/**
	 * 物体移动方向
	 */
	public int speed;
	/**
	 * 调停者（中介者）设计模式 持有MapleStoryClient类的引用
	 */
	public MapleStoryClient msc;

	/**
	 * 表示生死的变量
	 */
	public boolean live = true;

	/**
	 * 英雄方向的枚举类型
	 */
	public Direction dir;
	/**
	 * 英雄动作的枚举类型
	 */
	public Action action;

	/**
	 * 血量
	 */
	public double HP;
	/**
	 * 满血
	 */
	public double HP_FULL;
	/**
	 * 蓝量
	 */
	public double MP;
	/**
	 * 满蓝
	 */
	public double MP_FULL;
	/**
	 * 等级
	 */
	public int level;
	/**
	 * 经验值
	 */
	public int EXP;
	/**
	 * 宽度
	 */
	public int width;
	/**
	 * 高度
	 */
	public int height;

	/**
	 * 画的方法
	 */
	@Override
	public abstract void draw(Graphics g);

	/**
	 * 移动方法
	 */
	@Override
	public abstract void move();

	/**
	 * 获取对象图片所在矩形
	 * 
	 * @return Rectangle 矩形
	 */
	public Rectangle getRectangle() {
		return new Rectangle(x, y, width, height);
	}

}
