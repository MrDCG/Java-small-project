package com.neuedu.maplestory.entity;

import java.awt.Graphics;
import java.awt.Image;
import java.util.List;
import java.util.Random;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;

/**
 * 箭类（子弹）
 * 
 * @author MrDCG
 * @version 创建时间：2019年8月19日 下午2:27:04
 *
 */
public class Arrow extends MapleStoryObject {

	/**
	 * 存放图片的数组
	 */
	public static Image[] imgs = new Image[20];
	/**
	 * 静态加载图片
	 */
	static {
		// 攻击左
		for (int i = 0; i < 5; i++) {
			imgs[i] = ImageUtil.get("bullet_arrow_l" + i);
		}
		// 攻击右
		for (int i = 5; i < 10; i++) {
			imgs[i] = ImageUtil.get("bullet_arrow_r" + (i - 5));
		}
	}

	/**
	 * 空参构造
	 */
	public Arrow() {
	}

	/**
	 * 有参构造
	 * 
	 * @param msc MapleStoryClient 调停者
	 * @param x   横坐标
	 * @param y   纵坐标
	 * @param dir 技能方向
	 */
	public Arrow(MapleStoryClient msc, int x, int y, Direction dir) {
		this.msc = msc;
		this.x = x;
		this.y = y;
//		this.img = ImageUtil.get("bullet_arrow_r");
		this.dir = dir;
		if (dir == Direction.LEFT) {
			this.img = ImageUtil.get("bullet_arrow_l1");
		} else {
			this.img = ImageUtil.get("bullet_arrow_r1");
		}
		this.speed = 50;
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
	}

	/**
	 * 有参构造
	 * 
	 * @param msc MapleStoryClient 调停者
	 * @param x   横坐标
	 * @param y   纵坐标
	 * @param dir 技能方向
	 * @param img 图片
	 */
	public Arrow(MapleStoryClient msc, int x, int y, Direction dir, Image img) {
		this(msc, x, y, dir);
		this.img = img;
	}

	/**
	 * 向左的技能图记录值
	 */
	private int bullet1_l_count = 0;
	/**
	 * 向右的技能图记录值
	 */
	private int bullet1_r_count = 5;

	/**
	 * 重写的父类的画的方法
	 */
	@Override
	public void draw(Graphics g) {
		if (bullet1_l_count > 4) {
			bullet1_l_count = 0;
		}
		if (bullet1_r_count > 9) {
			bullet1_r_count = 5;
		}
		if (dir == Direction.LEFT) {
			g.drawImage(imgs[bullet1_l_count++], x, y, null);
		} else {
			g.drawImage(imgs[bullet1_r_count++], x, y, null);
		}
		move();
	}

	/**
	 * 重写的父类移动的方法
	 */
	@Override
	public void move() {
		if (this.dir == Direction.LEFT) {
			this.x -= speed;

		} else {
			this.x += speed;
		}
		// 边界判断
		outOfBound();
	}

	/**
	 * 边界判断
	 */
	private void outOfBound() {
		if (this.x > Constant.GAME_WIDTH + 500 || this.x < -500) {
			msc.arrows.remove(this);
		}
	}

	/**
	 * 随机数
	 */
	private static Random r = new Random();

	/**
	 * 碰撞检测
	 * 
	 * @param mob 怪物
	 * @return 是否碰撞
	 */
	public boolean hit(Mob mob) {
		if (this.live && mob.live && mob.action != Action.DIE && this.getRectangle().intersects(mob.getRectangle())) {
			// 业务逻辑
			this.live = false;
			msc.arrows.remove(this);
			mob.HP -= msc.hero.attackPower;
			if (mob.HP <= 0) {
				mob.action = Action.DIE;
				if (r.nextInt(100) > 0) {
					Item item = new Item(msc, mob.x + mob.width / 2, mob.y + mob.height - 30, r.nextInt(5));
					msc.items.add(item);
				}

			}

			return true;
		}
		return false;
	}

	/**
	 * hit方法的重载，每只弓箭要循环遍历Mobs的每只怪
	 * 
	 * @param mobs 怪物集合
	 * @return 打中返回true
	 */
	public boolean hit(List<Mob> mobs) {
		for (int i = 0; i < mobs.size(); i++) {
			Mob mob = mobs.get(i);
			if (this.hit(mob)) {
				return true;
			}
		}
		return false;
	}

}
