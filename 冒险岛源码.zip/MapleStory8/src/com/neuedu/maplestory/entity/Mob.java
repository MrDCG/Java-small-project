package com.neuedu.maplestory.entity;

import java.awt.Graphics;

/**
 * @author MrDCG
 * @version 创建时间：2019年8月20日 上午9:28:03
 *
 */
public abstract class Mob extends MapleStoryObject {
	/**
	 * 怪物名字
	 */
	public String name;
	/**
	 * 是否攻击
	 */
	public boolean attack;

	/**
	 * 画的方法
	 */
	@Override
	public abstract void draw(Graphics g);

	/**
	 * 移动方法
	 */
	@Override
	public abstract void move();

}
