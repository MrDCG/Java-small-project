package com.neuedu.maplestory.entity;

import java.awt.Graphics;
import java.awt.Image;

import com.neuedu.maplestory.util.ImageUtil;

/** 
* @author MrDCG 
* @version 创建时间：2019年8月24日 下午8:00:31 
*
*/
class BloodBar {
	int x;
	int y;
	Image img;
	/**
	 * 空参构造
	 */
	public BloodBar() {

	}

	/**
	 * 有参构造
	 * @param x 横坐标
	 * @param y 纵坐标 
	 * @param key 图片名
	 */
	public BloodBar(int x, int y, String key) {
		this.x = x;
		this.y = y;
		this.img = ImageUtil.get(key);
	}
	/**
	 * draw方法
	 * @param g 画笔
	 */
	public void draw(Graphics g) {
		g.drawImage(img, x, y, null);
	}



}