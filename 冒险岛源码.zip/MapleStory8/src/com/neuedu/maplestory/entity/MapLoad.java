//package com.neuedu.maplestory.entity;
//
//import java.awt.Graphics;
//import java.awt.Image;
//
//public class MapLoad extends MapleStoryObject {
//
//	public MapLoad() {
//
//	}
//
//	public MapLoad(int x, int y, Image img) {
//		this.x = x;
//		this.y = y;
//		this.img = img;
//	}
//
//	@Override
//	public void draw(Graphics g) {
//		g.drawImage(img, x, y, null);
//
//	}
//
//	@Override
//	public void move() {
//
//	}
//
//}

package com.neuedu.maplestory.entity;

import java.awt.Graphics;
import java.awt.Image;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;

public class MapLoad extends MapleStoryObject {

	/**
	 * 表示人物移动方向的boolean变量
	 */

	public boolean left, up, right, down, walk;
	/**
	 * hero的速度
	 */
	public int speed;
	/**
	 * hero的宽度
	 */
	public int width;
	/**
	 * hero的高度
	 */
	public int height;

	/**
	 * 空参构造
	 */
	public MapLoad() {

	}

	/**
	 * 有参构造
	 * 
	 * @param msc 调停者
	 * @param img 图片
	 */
	public MapLoad(MapleStoryClient msc, Image img) {
		this.msc = msc;
		this.x = 0;
		this.y = 0;
		this.img = img;
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
		this.speed = Constant.HERO_SPEED;
	}

	/**
	 * 画的方法
	 */
	@Override
	public void draw(Graphics g) {
		g.drawImage(img, x, y, null);
//		move();

	}

	/**
	 * 移动方法
	 */
	@Override
	public void move() {
		if (msc.hero.left) {
			if (msc.hero.walk) {

				x += speed;
			}

		}
		if (msc.hero.right) {
			if (msc.hero.walk) {
				x -= speed;
			}

		}

		/**
		 * 边界判断
		 */
		outOfBound();

	}

	/**
	 * 边界判断
	 */
	private void outOfBound() {
		if (x <= Constant.GAME_WIDTH - width) {
			x = Constant.GAME_WIDTH - width;

		}
		if (x > 0) {
			x = 0;
		}
	}
}
