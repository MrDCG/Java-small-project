package com.neuedu.maplestory.entity;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.util.ImageUtil;

/**
 * @author MrDCG
 * @version 创建时间：2019年8月20日 上午9:33:01
 *
 */
public class Mob1 extends Mob {
	/**
	 * 图片的数组
	 */
	public static Image[] imgs = new Image[100];
	/**
	 * 静态方法加载图片
	 */
	static {
		// mob1 stand
		// right
		for (int i = 0; i < 5; i++) {
			imgs[i] = ImageUtil.get("mob1_r" + i);
		}
		// left
		for (int i = 5; i < 10; i++) {
			imgs[i] = ImageUtil.get("mob1_l" + (i - 5));
		}
		// mob1 walk
		// right
		for (int i = 10; i < 15; i++) {
			imgs[i] = ImageUtil.get("mob1_walk_r" + (i - 10));
		}
		// left
		for (int i = 15; i < 20; i++) {
			imgs[i] = ImageUtil.get("mob1_walk_l" + (i - 15));
		}
		// mob1 die
		// left
		for (int i = 20; i < 29; i++) {
			imgs[i] = ImageUtil.get("mob1_die_l" + (i - 20));
		}
		// right
		for (int i = 29; i < 38; i++) {
			imgs[i] = ImageUtil.get("mob1_die_r" + (i - 29));
		}

		// mob1 attack
		// left
		for (int i = 38; i < 59; i++) {
			imgs[i] = ImageUtil.get("mob1_attack_l" + (i - 38));
		}
		// right
		for (int i = 59; i < 80; i++) {
			imgs[i] = ImageUtil.get("mob1_attack_r" + (i - 59));
		}
	}

	/**
	 * 空参构造
	 */
	public Mob1() {

	}

	/**
	 * 有参构造
	 * 
	 * @param msc        调停者
	 * @param x          横坐标
	 * @param y          纵坐标
	 * @param actionType 运动状态
	 */
	public Mob1(MapleStoryClient msc, int x, int y, int actionType) {
		switch (actionType) {
		case 0:
			this.dir = Direction.LEFT;
			this.action = Action.WALK;
			break;
		case 1:
			this.dir = Direction.LEFT;
			this.action = Action.STAND;
			break;
		case 2:
			this.dir = Direction.RIGHT;
			this.action = Action.WALK;
			break;
		case 3:
			this.dir = Direction.RIGHT;
			this.action = Action.STAND;
			break;

		default:
			break;
		}
		this.name = "白雀";
		this.msc = msc;
		this.x = x;
		this.y = y;
		this.width = imgs[0].getWidth(null);
		this.height = imgs[0].getHeight(null);
		this.HP = 100;
		this.HP_FULL = this.HP;
		this.speed = 5;
		this.level = 60;
		this.EXP = 5600;
	}

	/**
	 * 站立图片计数器
	 */
	private int mob1_stand_rcount = 0;
	/**
	 * 站立图片计数器
	 */
	private int mob1_stand_lcount = 5;
	/**
	 * 走的图片计数器
	 */
	private int mob1_walk_rcount = 10;
	/**
	 * 走的图片计数器
	 */
	private int mob1_walk_lcount = 15;
	/**
	 * 死亡图片计数器
	 */
	private int mob1_die_lcount = 20;
	/**
	 * 死亡图片计数器
	 */
	private int mob1_die_rcount = 29;
	/**
	 * 攻击图片计数器
	 */
	private int mob1_attack_lcount = 38;
	/**
	 * 攻击图片计数器
	 */
	private int mob1_attack_rcount = 59;

	/**
	 * 计数方法
	 */
	private void count() {
		if (mob1_stand_rcount > 4) {
			mob1_stand_rcount = 0;
		}
		if (mob1_stand_lcount > 9) {
			mob1_stand_lcount = 5;
		}
		if (mob1_walk_rcount > 14) {
			mob1_walk_rcount = 10;
		}
		if (mob1_walk_lcount > 19) {
			mob1_walk_lcount = 15;
		}
		if (mob1_die_lcount > 28) {
			mob1_die_lcount = 20;
			live = false;
			msc.mobs.remove(this);
			msc.hero.EXP += this.EXP;
			rate = 0;
		}
		if (mob1_die_rcount > 37) {
			mob1_die_rcount = 29;
			live = false;
			msc.mobs.remove(this);
			msc.hero.EXP += this.EXP;
			rate = 0;
		}
		if (mob1_attack_lcount > 58) {
			mob1_attack_lcount = 38;
		}
		if (mob1_attack_rcount > 79) {
			mob1_attack_rcount = 59;
		}
	}

	/**
	 * 行动状态
	 */
	private Random actionType = new Random();
	/**
	 * 速率
	 */
	private int rate = 0;

	/**
	 * 画的方法
	 */
	@Override
	public void draw(Graphics g) {
		count();
		switch (dir) {
		case LEFT:
			switch (action) {
			case STAND:
				g.drawImage(imgs[mob1_stand_lcount++], x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[mob1_walk_lcount++], x, y, null);
				break;
			case DIE:
				if (live) {
					g.drawImage(imgs[mob1_die_lcount++], x - 10, y - 30, null);
				}
				break;
			case ATTACK:
				g.drawImage(imgs[mob1_attack_lcount++], x - 200, y - 120, null);
				break;
			default:
				break;
			}
			break;
		case RIGHT:
			switch (action) {
			case STAND:
				g.drawImage(imgs[mob1_stand_rcount++], x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[mob1_walk_rcount++], x, y, null);
				break;
			case DIE:
				if (live) {
					g.drawImage(imgs[mob1_die_rcount++], x - 20, y - 30, null);
				}
				break;
			case ATTACK:
				g.drawImage(imgs[mob1_attack_rcount++], x - 200, y - 120, null);
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		if (!attack) {

			drawBloodBar(g);
			drawInfo(g);
		}
		move();

		rate++;
		if (msc.mobs.size() != 0) {
			if (rate == 20 && this.action != Action.DIE) {
				switch (actionType.nextInt(4)) {
				case 0:
					if (attack) {
						this.action = Action.ATTACK;
						if (msc.hero.left) {
							this.dir = Direction.RIGHT;
						} else {
							this.dir = Direction.LEFT;
						}
					} else {
						this.dir = Direction.LEFT;
						this.action = Action.WALK;
					}

					break;
				case 1:
					if (attack) {
						this.action = Action.ATTACK;
						if (msc.hero.left) {
							this.dir = Direction.RIGHT;
						} else {
							this.dir = Direction.LEFT;
						}
					} else {
						this.dir = Direction.LEFT;
						this.action = Action.STAND;
					}

					break;
				case 2:
					if (attack) {
						this.action = Action.ATTACK;
						if (msc.hero.left) {
							this.dir = Direction.RIGHT;
						} else {
							this.dir = Direction.LEFT;
						}

					} else {
						this.dir = Direction.RIGHT;
						this.action = Action.WALK;
					}

					break;
				case 3:
					if (attack) {
						this.action = Action.ATTACK;
						if (msc.hero.left) {
							this.dir = Direction.RIGHT;
						} else {
							this.dir = Direction.LEFT;
						}
					} else {
						this.dir = Direction.RIGHT;
						this.action = Action.STAND;
					}

					break;

				default:
					break;
				}
				rate = 0;
			}
		}

		hit(msc.hero);
	}

	/**
	 * 画怪物名字的方法
	 * 
	 * @param g 画笔
	 */
	private void drawInfo(Graphics g) {
		int x = this.x + 8;
		int y = this.y + this.height + 15;
		Color c = g.getColor();
		Font f = g.getFont();
		g.setFont(new Font("微软雅黑", Font.PLAIN, 15));
		g.setColor(new Color(0.5f, 0.5f, 0.5f, 0.5f));
		g.fillRect(x, y - 10, 80, 16);
		g.setColor(Color.BLACK);
		g.drawString("LV." + level + " " + name, x, y + 5);
		g.setColor(c);
		g.setFont(f);
	}

	/**
	 * 画血条
	 * 
	 * @param g 画笔
	 */
	private void drawBloodBar(Graphics g) {
		for (int i = 0; i < (this.width / 1) * (HP / HP_FULL); i++) {
			if (HP / HP_FULL <= 1 && HP / HP_FULL > 0.7) {
				BloodBar bs0 = new BloodBar(this.x + (i * 1), this.y - 16, "blooddiv0");
				bs0.draw(g);

			} else if (HP / HP_FULL <= 0.7 && HP / HP_FULL > 0.3) {
				BloodBar bs1 = new BloodBar(this.x + (i * 1), this.y - 16, "blooddiv1");
				bs1.draw(g);
			} else {
				BloodBar bs2 = new BloodBar(this.x + (i * 1), this.y - 16, "blooddiv2");
				bs2.draw(g);
			}
		}

	}

	/**
	 * 移动
	 */
	@Override
	public void move() {
		switch (dir) {
		case LEFT:
			switch (action) {
			case STAND:
				break;
			case WALK:
				x -= speed;
				break;
			default:
				break;
			}
			break;
		case RIGHT:
			switch (action) {
			case STAND:

				break;
			case WALK:
				x += speed;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}

		outOfBound();
	}

	/**
	 * 边界判断
	 */
	private void outOfBound() {
		if (x <= msc.mapload.x) {
			this.dir = Direction.RIGHT;
		}
		if (x > msc.mapload.x + 1800) {
			this.dir = Direction.LEFT;
		}

	}

	/**
	 * 攻击的方法
	 * 
	 * @param hero 英雄
	 * @return 是否击中
	 */
	public boolean hit(Hero hero) {
		if (hero.live && this.action != Action.DIE && this.getRectangle().intersects(hero.getRectangle())) {
			// 业务逻辑
//			hero.HP -= 20;
			Random r = new Random();

			if (r.nextInt(20) > 18) {
				hero.HP -= 50 - hero.defense;
			}
			attack = true;
			return attack;
		}
		attack = false;
		return attack;
	}

}
