package com.neuedu.maplestory.entity;

import java.awt.Graphics;
import java.awt.Image;
import java.util.List;
import java.util.Random;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;

/**
 * 箭类（子弹）
 * 
 * @author MrDCG
 * @version 创建时间：2019年8月19日 下午2:27:04
 *
 */
public class Skill extends MapleStoryObject {
	/**
	 * 存放技能图片
	 */
	public static Image[] imgs = new Image[20];
	/**
	 * 静态方法加载图片
	 */
	static {
		// 攻击左
		for (int i = 0; i < 16; i++) {
			imgs[i] = ImageUtil.get("hero_skill" + i);
		}
	}

	/**
	 * 空参构造
	 */
	public Skill() {
	}

	/**
	 * 有参构造
	 * 
	 * @param msc 调停者
	 * @param x   横坐标
	 * @param y   纵坐标
	 * @param dir 方向
	 */
	public Skill(MapleStoryClient msc, int x, int y, Direction dir) {
		this.msc = msc;
		this.x = x;
		this.y = y;
		this.img = ImageUtil.get("hero_skill1");
		this.dir = dir;
		this.speed = 50;
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
	}

	/**
	 * 有参构造
	 * 
	 * @param msc 调停者
	 * @param x   横坐标
	 * @param y   纵坐标
	 * @param dir 方向
	 * @param img 图片
	 */
	public Skill(MapleStoryClient msc, int x, int y, Direction dir, Image img) {
		this(msc, x, y, dir);
		this.img = img;
	}

	/**
	 * 技能图片统计
	 */
	private int skill_count = 0;
	/**
	 * 控制技能发出时间
	 */
	private int move_count = 0;

	/**
	 * 画的方法
	 */
	@Override
	public void draw(Graphics g) {
		if (skill_count > 15) {
			skill_count = 0;
		}
		g.drawImage(imgs[skill_count++], x, y, null);
		move_count++;
		if (move_count >= 60) {
			move();
			skill_count = 13;
		}
	}

	/**
	 * 移动方法
	 */
	@Override
	public void move() {
		this.x += speed;

		// 边界判断
		outOfBound();
	}

	/**
	 * 边界判断
	 */
	private void outOfBound() {
		if (this.x > Constant.GAME_WIDTH + 500 || this.x < -500) {
			msc.skills.remove(this);
			move_count = 0;
			skill_count = 0;
			msc.hero.skill = false;
			msc.hero.fly = false;
		}
	}

	/**
	 * 随机数
	 */
	private static Random r = new Random();

	/**
	 * 碰撞检测
	 * 
	 * @param mob 怪物
	 * @return 是否碰撞
	 */
	public boolean hit(Mob mob) {
		if (this.live && mob.live && mob.action != Action.DIE && this.getRectangle().intersects(mob.getRectangle())) {
			// 业务逻辑
			this.live = false;
			mob.HP -= msc.hero.attackPower * 10;
			if (mob.HP <= 0) {
//				mob.live = false;
//				msc.mobs.remove(mob);
				mob.action = Action.DIE;
				if (r.nextInt(100) > 0) {
					Item item = new Item(msc, mob.x + mob.width / 2, mob.y + mob.height - 30, r.nextInt(5));
					msc.items.add(item);
				}

			}

			return true;
		}
		return false;
	}

	/**
	 * hit方法的重载，每只弓箭要循环遍历Mobs的每只怪
	 * 
	 * @param mobs 怪物集合
	 * @return 打中返回true
	 */
	public boolean hit(List<Mob> mobs) {
		for (int i = 0; i < mobs.size(); i++) {
			Mob mob = mobs.get(i);
			if (this.hit(mob)) {
				return true;
			}
		}
		return false;
	}

}
