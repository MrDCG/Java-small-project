package com.neuedu.maplestory.entity;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Random;
import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;
import com.neuedu.maplestory.util.MusicUtil;

/**
 * 
 * @author MrDCG
 *
 */
public class Hero extends MapleStoryObject {

	/**
	 * 存放图片的数组
	 */
	public static Image[] imgs = new Image[100];
	/**
	 * 加载图片的静态方法
	 */
	static {
		// 右走
		for (int i = 0; i < 5; i++) {
			imgs[i] = ImageUtil.get("hero_walk_r" + i);
		}
		// 左走
		for (int i = 5; i < 10; i++) {
			imgs[i] = ImageUtil.get("hero_walk_l" + (i - 5));
		}
		// 右发射
		for (int i = 10; i < 14; i++) {
			imgs[i] = ImageUtil.get("hero_shoot_r" + (i - 10));
		}
		// 左发射
		for (int i = 14; i < 18; i++) {
			imgs[i] = ImageUtil.get("hero_shoot_l" + (i - 14));
		}

		// 朝右站立
		for (int i = 18; i < 22; i++) {
			imgs[i] = ImageUtil.get("hero_stand_r" + (i - 18));
		}
		// 朝左站立
		for (int i = 22; i < 26; i++) {
			imgs[i] = ImageUtil.get("hero_stand_l" + (i - 22));
		}

		// 朝右射击特效
		for (int i = 26; i < 31; i++) {
			imgs[i] = ImageUtil.get("hero_skill1_r" + (i - 26));
		}
		// 朝左射击特效
		for (int i = 31; i < 36; i++) {
			imgs[i] = ImageUtil.get("hero_skill1_l" + (i - 31));
		}
		// 爬绳子
		imgs[36] = ImageUtil.get("hero_rope");
		// 爬梯子
		imgs[37] = ImageUtil.get("hero_ladder");
		// 升天特效
		for (int i = 38; i < 61; i++) {
			imgs[i] = ImageUtil.get("hero_skill2" + (i - 38));
		}
		// 飞的特效
		imgs[61] = ImageUtil.get("fly");
	}

	/**
	 * 表示人物移动方向的boolean变量
	 */
	public boolean left, up, right, down, walk, jump, shoot, pick, climb, step, fall, ladder, grass3, skill, small, mid,
			half, full, mp, die;

	// 朝右行走图计数器
	private int walk_right_count = 0;// [0,4]
	// 朝左行走图计数器
	private int walk_left_count = 5;// [5,9]
	// 朝右射击图计数器
	private int shoot_right_count = 10;// [10,13]
	// 朝左射击图计数器
	private int shoot_left_count = 14;// [14,17]
	// 朝右站立射击图计数器
	private int stand_right_count = 18;// [18,21]
	// 朝左站立射击图计数器
	private int stand_left_count = 22;// [22,25]
	// 朝右攻击特效图计数器
	private int skill1_right_count = 26;// [26,30]
	// 朝左攻击特效图计数器
	private int skill1_left_count = 31;// [31,35]
	// 翅膀特效
	private int skill2_count = 38;// [38,50]
	/**
	 * 攻击力
	 */
	public int attackPower;
	/**
	 * 防御力
	 */
	public int defense;

	/**
	 * 有参构造
	 * 
	 * @param msc MapleStoryClient调停者
	 */
	public Hero(MapleStoryClient msc) {
		this.msc = msc;
		this.x = 300;
		this.y = 860;
		this.speed = Constant.HERO_SPEED;
		this.dir = Direction.RIGHT;
		this.img = ImageUtil.get("hero_stand_r0");
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
		this.action = Action.STAND;
		this.HP = 1000;
		this.HP_FULL = this.HP;
		this.MP = 1000;
		this.MP_FULL = this.MP;
		this.level = 0;
		this.EXP = 0;
		this.attackPower = 10;
		this.defense = 10;
	}

	/**
	 * 有参构造
	 * 
	 * @param x   横坐标
	 * @param y   纵坐标
	 * @param msc MapleStoryClient调停者
	 */
	public Hero(int x, int y, MapleStoryClient msc) {
		this(msc);
		this.x = x;
		this.y = y;
	}

	/**
	 * 计数器的判断
	 */
	public void count() {

		if (walk_right_count > 4) {
			walk_right_count = 0;
		}
		if (walk_left_count > 9) {
			walk_left_count = 5;
		}
		if (shoot_right_count > 13) {
			shoot_right_count = 10;
		}
		if (shoot_left_count > 17) {
			shoot_left_count = 14;
		}
		if (stand_right_count > 21) {
			stand_right_count = 18;
		}
		if (stand_left_count > 25) {
			stand_left_count = 22;
		}
		if (skill1_right_count > 30) {
			skill1_right_count = 26;
		}
		if (skill1_left_count > 35) {
			skill1_left_count = 31;
		}
		if (skill2_count > 60) {
			skill2_count = 38;
		}

	}

	/**
	 * 技能冷却时间
	 */
	public int time_count = 0;
	/**
	 * 小血瓶冷却
	 */
	public int small_count = 0;
	/**
	 * 中血瓶冷却
	 */
	public int mid_count = 0;
	/**
	 * 半血瓶冷却
	 */
	public int half_count = 0;
	/**
	 * 满血瓶冷却
	 */
	public int full_count = 0;
	/**
	 * mp满血瓶冷却
	 */
	public int mp_count = 0;

	/**
	 * 画的方法
	 */
	@Override
	public void draw(Graphics g) {

		switch (dir) {
		case RIGHT:
			switch (action) {
			case STAND:
				g.drawImage(imgs[stand_right_count++], x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[walk_right_count++], x, y, null);
				break;
			case JUMP:
				g.drawImage(ImageUtil.get("hero_jump_r0"), x, y, null);
				break;
			case SHOOT:
				g.drawImage(imgs[shoot_right_count++], x, y, null);
				g.drawImage(imgs[skill1_right_count++], x, y + 20, null);
				new MusicUtil("heroattack/ordinaryattack").start();
				break;
			case CLIMB:
				g.drawImage(ImageUtil.get("hero_rope"), x, y, null);
				break;
			case SKILL:
				g.drawImage(imgs[61], x, y, null);
				g.drawImage(imgs[skill2_count++], x - 110, y - 50, null);
				break;
			default:
				break;
			}
			break;
		case LEFT:
			switch (action) {
			case STAND:
				g.drawImage(imgs[stand_left_count++], x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[walk_left_count++], x, y, null);
				break;
			case JUMP:
				g.drawImage(ImageUtil.get("hero_jump_l0"), x, y, null);
				break;
			case SHOOT:
				g.drawImage(imgs[shoot_left_count++], x, y, null);
				g.drawImage(imgs[skill1_left_count++], x - 120, y + 20, null);
				new MusicUtil("heroattack/ordinaryattack").start();
				break;
			case CLIMB:
				g.drawImage(ImageUtil.get("hero_rope"), x, y, null);
				break;
			case SKILL:
				g.drawImage(imgs[61], x, y, null);
				g.drawImage(imgs[skill2_count++], x - 110, y - 50, null);
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}

		// 判断方向
		confirmDirection();
//		move();
		// 计数器的判断
		count();
		if (shoot && !climb) {
			shoot();
		}

		if (time_count >= 180) {
			time_count = 180;
		}
		if (jump && !climb && !ladder) {
			jump(msc.rope1, msc.grass1);
		}
		if (fall && !step && !jump && !climb) {
			fall();
		}

		// 血条
		drawBloodBar(g);
		// 血量
		g.drawString("" + HP + "/" + HP_FULL, 160, 1038);
		// 蓝条
		drawMpBar(g);
		// 蓝量
		g.drawString("" + MP + "/" + MP_FULL, 160, 1055);
		// 切换图片
		changeImage();
		time_count++;
		if (skill && !climb && time_count >= 180 && MP >= 200) {
			skill();
			MP -= 200;
			time_count = 0;
		}
		move();
		heroUpdate();

		small_count++;
		mid_count++;
		half_count++;
		full_count++;
		mp_count++;
		if (small_count >= 40) {
			small_count = 40;
		}
		if (mid_count >= 50) {
			mid_count = 50;
		}
		if (half_count >= 55) {
			half_count = 55;
		}
		if (full_count >= 70) {
			full_count = 70;
		}
		if (mp_count >= 40) {
			mp_count = 40;
		}
		if (!die) {
			die();
		}

	}

	/**
	 * 改变图片的方法
	 */
	public void changeImage() {
		if (walk) {
			this.action = Action.WALK;
			if (shoot) {
				this.action = Action.SHOOT;
			}
			// 边走边跳
			if (jump) {
				this.action = Action.JUMP;
				if (shoot) {
					this.action = Action.SHOOT;
				}
			}

		}

		// 原地射击
		else if (shoot) {
			this.action = Action.SHOOT;
		}
		// 原地跳
		else if (jump) {
			this.action = Action.JUMP;
			if (shoot) {
				this.action = Action.SHOOT;
			}
		} else {
			this.action = Action.STAND;
		}
		if (skill && fly) {
			this.action = Action.SKILL;
		}
	}

	/**
	 * hero移动方法
	 */
	@Override
	public void move() {
		jump_land = 950;
		if (step) {
			jump_land = 320;
		}
		if (this.x >= 80 && this.x <= 470) {

			stepOnLand(msc.grass1);
		}
		if (this.x >= 520 && this.x <= 1290) {

			stepOnLand(msc.grass2);
		}
		if (this.x >= 1340 && this.x <= 1800) {
			stepOnLand(msc.grass3);
		} else if (!this.getRectangle().intersects(msc.grass3.getRectangle())) {
			grass3 = false;
		} else {
			grass3 = false;
		}
		if (this.x >= 170 && this.x <= 380) {
			climb(msc.rope1);
		}
		if (this.x >= 570 && this.x <= 760) {

			climb(msc.rope2);
		}
		if (this.x >= 930 && this.x <= 1180) {

			climb(msc.rope3);
		}

		ladder();
		if (walk) {
			if (right) {
				x += speed;
			}

			if (left) {
				x -= speed;
			}

		}
		if (climb) {
			if (up) {
				y -= speed;
			}
			if (down) {
				y += speed;
			}

		}
		if (ladder) {
			if (up) {
				y -= speed;
				x += 5;
			}
			if (down) {
				y += speed;
				x -= 5;
			}
		}
		if (fly) {
			y = 200;
			x = 700;
		}
		if (this.x >= 80 && this.x <= 470) {

			freeFall(msc.grass1);
		}
		if (this.x >= 520 && this.x <= 1290) {

			freeFall(msc.grass2);
		}
		if (this.x >= 1340 && this.x <= 1800) {
			freeFall(msc.grass3);
		}
		/**
		 * 边界判断
		 */
		outOfBound();

	}

	/**
	 * 从空中落下的方法
	 * 
	 * @param grass 草地对象
	 */
	public void freeFall(Grassland grass) {
		if (!this.getRectangle().intersects(grass.getRectangle())) {
			if (!step) {
				if (this.y < 860) {
					fall = true;
				}
			}

		}
	}

	/**
	 * 判断方向
	 */
	private void confirmDirection() {
		if (left) {
			this.dir = Direction.LEFT;
		}
		if (right) {
			this.dir = Direction.RIGHT;
		}
	}

	/**
	 * 判断怪物移动位置
	 */
	public boolean mob_move;

	/**
	 * 边界判断
	 */
	private void outOfBound() {
		if (x <= 0) {
			x = 0;
			msc.mapload.move();
			mob_move = true;
		} else if (x > Constant.GAME_WIDTH - width) {
			x = Constant.GAME_WIDTH - width;
			msc.mapload.move();
			mob_move = true;

		}

	}

	/**
	 * 按键控制移动 w↑ a← s↓ d→
	 * 
	 * @param e 键盘事件对象
	 */

	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		// 左
		case KeyEvent.VK_A:
			left = true;
			walk = true;
			break;
//		 右
		case KeyEvent.VK_D:
			right = true;
			walk = true;
			break;
		// 上
		case KeyEvent.VK_W:
			up = true;

			break;
		// 下
		case KeyEvent.VK_S:
			down = true;

			break;
//			跳
		case KeyEvent.VK_K:
			jump = true;
			break;
//			普攻
		case KeyEvent.VK_J:
			shoot = true;
			break;
//			流星箭矢
		case KeyEvent.VK_H:
			skill = true;
			break;
//			拾取
		case KeyEvent.VK_L:
			pick = true;
			break;
//			使用小血瓶
		case KeyEvent.VK_1:
			small = true;
			break;
//			使用中血瓶
		case KeyEvent.VK_2:
			mid = true;
			break;
//			使用半血瓶
		case KeyEvent.VK_3:
			half = true;
			break;
//			使用满血瓶
		case KeyEvent.VK_4:
			full = true;
			break;
//			使用小蓝瓶
		case KeyEvent.VK_5:
			mp = true;
			break;

		default:
			break;
		}

	}

	/**
	 * 按键抬起控制 w↑ a← s↓ d→
	 * 
	 * @param e 键盘事件对象
	 */
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		// 左
		case KeyEvent.VK_A:
			left = false;
			walk = false;
			break;
		// 右
		case KeyEvent.VK_D:
			right = false;
			walk = false;
			break;
		// 上
		case KeyEvent.VK_W:
			up = false;

			break;
		// 下
		case KeyEvent.VK_S:
			down = false;

			break;
//			射击
		case KeyEvent.VK_J:
			shoot = false;
			break;
//			流星箭矢
		case KeyEvent.VK_H:
			if (!fly) {

				skill = false;
			}
			break;
//			拾取
		case KeyEvent.VK_L:
			pick = false;
			break;
//			使用小血瓶
		case KeyEvent.VK_1:
			small = false;
			break;
//			使用中血瓶
		case KeyEvent.VK_2:
			mid = false;
			break;
//			使用半血瓶
		case KeyEvent.VK_3:
			half = false;
			break;
//			使用满血瓶
		case KeyEvent.VK_4:
			full = false;
			break;
//			使用小蓝瓶
		case KeyEvent.VK_5:
			mp = false;
			break;
		default:
			break;
		}

	}

	/**
	 * 初速度
	 */
	private double v0 = Constant.HERO_JUMP_SPEED;
	/**
	 * 末速度
	 */
	private double vt = 0;
	/**
	 * 单位时间位移量
	 */
	private double delta_h = 0;
	/**
	 * 重力加速度
	 */
	private static final double g = 9.8;
	/**
	 * 单位时间
	 */
	private double t = 0.5;
	/**
	 * 跳起方向
	 */
	private boolean jump_up = true; // 默认向上
	/**
	 * 落地
	 */
	public int jump_land = 950;

	/**
	 * 跳的算法
	 * 
	 * @param rope  绳子
	 * @param grass 草地
	 */
	public void jump(Rope rope, Grassland grass) {

		if (jump_up) {
			// 竖直上抛
			vt = v0 - g * t;
			v0 = vt;
			delta_h = v0 * t;
			y -= delta_h;
			if (vt <= 0) {

				vt = 0;
				v0 = 0;
				jump_up = false; // 进入自由落体
			}

		} else {

			// 自由落体
			vt = v0 + g * t;
			v0 = vt;
			delta_h = v0 * t;
			y += delta_h;
			if (this.getRectangle().intersects(grass.getRectangle())) {
				if (this.y + this.height <= grass.y + 40) {
					jump_land = grass.y + 40;
				}
			}
			// 结束自由落体
			if (!this.getRectangle().intersects(rope.getRectangle())) {
				if (y + this.height > jump_land) {
					if (jump_land == 320) {
						y = 320;
						if (grass3) {
							y = 570;
						}
					} else {
						y = jump_land - this.height;
					}
					jump_up = true;
					// 下次竖直上抛的两个速度
					v0 = Constant.HERO_JUMP_SPEED;
					vt = 0;
					jump = false;
					this.action = Action.STAND;
				}
			} else {
				jump_up = true;
				// 下次竖直上抛的两个速度
				v0 = Constant.HERO_JUMP_SPEED;
				vt = 0;
				jump = false;
				this.action = Action.STAND;
			}

		}
	}

	/**
	 * 控制英雄自由落体的bool变量
	 */
	public boolean fall_down = true;
	/**
	 * 记录hero在地上时的y值
	 */
	private int hero_y = 860;

	/**
	 * 自由落体
	 */
	public void fall() {
		hero_y = 860;
		vt = 0;
		v0 = 0;
		// 自由落体
		vt = v0 + g * 2;
		v0 = vt;
		delta_h = v0 * 2;
		y += delta_h;
		if (this.x >= 1340 && this.x <= 1800) {
			hero_y = 570;
		}
		if (y > hero_y) {
			y = hero_y;
			fall_down = true;
			// 下次竖直上抛的两个速度
			v0 = Constant.HERO_JUMP_SPEED;
			vt = 0;
//					jump = false;
			fall = false;
			this.action = Action.STAND;
		}

//		}
	}

	/**
	 * 射击速率
	 */
	private int rate_count = 1;

	/**
	 * 射击方法
	 */
	public void shoot() {
		Arrow arrow = null;
		switch (dir) {
		case LEFT:
			rate_count++;
			if (rate_count == 3) {
				arrow = new Arrow(msc, this.x - 90, this.y + height / 2, this.dir);
				rate_count = 0;
			}
			break;
		case RIGHT:
			rate_count++;
			if (rate_count == 3) {
				arrow = new Arrow(msc, this.x + width, this.y + height / 2, this.dir);
				rate_count = 0;
			}
			break;

		default:
			break;
		}
		if (arrow != null) {
			msc.arrows.add(arrow);
		}
	}

	/**
	 * 技能纵坐标随机值
	 */
	private Random r1 = new Random();
	/**
	 * 技能横坐标随机值
	 */
	private Random r2 = new Random();
	/**
	 * 是否起飞
	 */
	public boolean fly;

	/**
	 * 释放 技能方法
	 */
	public void skill() {
		Skill skill = null;
		fly = true;
		for (int i = 0; i < 50; i++) {
			skill = new Skill(msc, r2.nextInt(1000) + 20, r1.nextInt(750) + 20, this.dir);
			msc.skills.add(skill);
		}
	}

	/**
	 * 拾取道具
	 * 
	 * @param item 道具
	 * @return 是否拾取
	 */
	public boolean eatItem(Item item) {
		if (item.live && this.getRectangle().intersects(item.getRectangle())) {
			if (pick) {
				switch (item.itemType) {
				case 0:
					msc.small_item.add(item);

					break;
				case 1:
					msc.half_item.add(item);

					break;
				case 2:
					msc.mid_item.add(item);

					break;
				case 3:
					msc.mp_item.add(item);

					break;
				case 4:
					msc.full_item.add(item);
					break;

				default:
					break;
				}
				msc.items.remove(item);
			}

			return true;
		}

		return false;
	}

	/**
	 * 有多个道具拾取
	 * 
	 * @param items 道具
	 * @return 是否拾取
	 */
	public boolean eatItem(List<Item> items) {

		for (int i = 0; i < items.size(); i++) {
			Item item = items.get(i);
			if (eatItem(item)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 爬的方法
	 * 
	 * @param rope 绳子对象
	 * @return 是否爬
	 */
	public boolean climb(Rope rope) {
		if (this.x + width / 2 >= rope.x && this.x + width / 2 + 10 <= rope.x + 30) {
			if (up) {
				if ((this.y >= (rope.y - this.height)) && (this.y <= 860)) {
					this.action = Action.CLIMB;
					climb = true;
					return climb;
				}
			}
			if (rope.y - this.height < this.y && this.y < 860) {
				this.action = Action.CLIMB;
				climb = true;
				return climb;
			}
			if (down) {
				if ((this.y >= (rope.y - this.height - 10)) && (this.y < 860)) {
					this.action = Action.CLIMB;
					climb = true;
					return climb;
				}
			}

		}
		climb = false;
		return climb;
	}

	/**
	 * 站在空中平台的方法
	 * 
	 * @param grass 草地
	 * @return 是否站在草地上
	 */
	public boolean stepOnLand(Grassland grass) {

		if (this.getRectangle().intersects(grass.getRectangle())) {
			if (this.y + this.height <= grass.y + 40) {
				if (this.x >= 1340 && this.x <= 1800) {
					grass3 = true;
				} else {
					grass3 = false;
				}
				step = true;
				return step;
			}

		}

		step = false;
		return step;
	}

	/**
	 * 上楼梯的方法
	 * 
	 * @return 是否在楼梯上
	 */
	public boolean ladder() {
		if (this.x >= 1540 && this.x <= 1750) {
			if (up) {
				if (this.y <= 860 && this.y - this.height >= 860 - 371) {
					ladder = true;
					this.action = Action.WALK;
					this.dir = Direction.RIGHT;
					return ladder;
				}

			}
			if (down) {
				if (this.y < 860 && this.y - this.height >= 860 - 380) {
					ladder = true;
					this.action = Action.WALK;
					this.dir = Direction.LEFT;
					return ladder;
				}
			}
			if (this.y < 860 && this.y - this.height >= 860 - 371) {
				ladder = true;
				this.action = Action.STAND;
				return ladder;
			}
		}
		ladder = false;
		return ladder;
	}

	/**
	 * 画血条
	 * 
	 * @param g 画笔
	 */
	private void drawBloodBar(Graphics g) {
		for (int i = 0; i < (165 / 1) * (HP / HP_FULL); i++) {
			BloodBar bs = new BloodBar(128 + i, 1031, "blooddiv0");
			bs.draw(g);
		}

	}

	/**
	 * 画蓝
	 * 
	 * @param g
	 */
	private void drawMpBar(Graphics g) {
		for (int i = 0; i < (165 / 1) * (MP / MP_FULL); i++) {
			BloodBar bs = new BloodBar(128 + i, 1047, "blooddiv3");
			bs.draw(g);
		}

	}

	/**
	 * 吃血恢复
	 */
	public void recovery() {
		if (small && small_count == 40) {
			if (msc.small_item.size() > 0) {
				msc.small_item.remove(0);
				small_count = 0;
				if (HP + 50 <= HP_FULL) {
					HP += 50;
				} else {
					HP = HP_FULL;
				}
			}
		}
		if (mid && mid_count == 50) {
			if (msc.mid_item.size() > 0) {
				msc.mid_item.remove(0);
				mid_count = 0;
				if (HP + 150 <= HP_FULL) {
					HP += 150;
				} else {
					HP = HP_FULL;
				}
			}
		}
		if (half && half_count == 55) {
			if (msc.half_item.size() > 0) {
				msc.half_item.remove(0);
				half_count = 0;
				if (HP <= HP_FULL / 2) {
					HP = HP_FULL / 2;
				}
			}
		}
		if (full && full_count == 70) {
			if (msc.full_item.size() > 0) {
				msc.full_item.remove(0);
				full_count = 0;
				if (HP <= HP_FULL) {
					HP = HP_FULL;
				}
			}
		}
		if (mp && mp_count == 40) {
			if (msc.mp_item.size() > 0) {
				msc.mp_item.remove(0);
				mp_count = 0;
				if (MP + 100 <= MP_FULL) {
					MP += 100;
				} else {
					MP = MP_FULL;
				}
			}
		}

	}

	/**
	 * 英雄升级的方法
	 */
	public void heroUpdate() {
		if ((this.level + 10) * 1000 <= this.EXP) {
			this.EXP -= (this.level + 10) * 1000;
			this.level += 1;
			HP_FULL += (this.level + 1) * 100;
			HP = HP_FULL;
			MP_FULL += (this.level + 1) * 10;
			MP = MP_FULL;
			attackPower += this.level * 2;
			defense += this.level;
			if (defense >= 50) {
				defense = 50;
			}
		}
	}

	/**
	 * 控制进入提示框次数
	 */
	public int die_count;

	/**
	 * 判断英雄是否死亡
	 */
	public void die() {
		if (HP <= 0) {
			this.action = Action.DIE;
			die = true;
			die_count = 1;
		}

	}
}
