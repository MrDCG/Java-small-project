package com.neuedu.maplestory.entity;
/** 
* @author MrDCG 
* @version 创建时间：2019年8月19日 上午9:14:26 
*
*/
public enum Direction {
	LEFT,RIGHT
}
