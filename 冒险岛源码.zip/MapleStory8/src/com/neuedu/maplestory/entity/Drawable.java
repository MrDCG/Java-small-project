package com.neuedu.maplestory.entity;

import java.awt.Graphics;

/**
 * 画的接口
 * 
 * @author Minemine
 *
 */
public interface Drawable {
	/**
	 * 所有物体对象都要画出来
	 * 
	 * @param g 画笔
	 */
	void draw(Graphics g);

}
