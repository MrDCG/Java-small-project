package com.neuedu.maplestory.constant;

/**
 * 
 */
import java.io.IOException;
import java.util.Properties;

public class Constant {
	/**
	 * 用于加载.properties文件属性
	 */
	private static Properties props = new Properties();
	/**
	 * 静态加载 文件数据
	 */
	static {
		try {
			props.load(Constant.class.getClassLoader().getResourceAsStream("maplestory.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 将String类型数据转化为int型
	 * 
	 * @param key 键值
	 * @return int类型数据
	 */
	public static int getProperty(String key) {
		return Integer.parseInt(props.getProperty(key));

	}

	/**
	 * 窗口宽度
	 */
	public static int GAME_WIDTH = getProperty("GAME_WIDTH");
	/**
	 * 窗口高度
	 */
	public static int GAME_HEIGHT = getProperty("GAME_HEIGHT");
	/**
	 * 图片前缀
	 */
	public static String IMG_PRE = props.getProperty("IMG_PRE");
	/**
	 * 音乐前缀
	 */
	public static String MUSIC_IMG_PRE = props.getProperty("MUSIC_IMG_PRE");
	/**
	 * Hero的速度
	 */
	public static int HERO_SPEED = getProperty("HERO_SPEED");
	/**
	 * hero跳的方法
	 */
	public static int HERO_JUMP_SPEED = getProperty("HERO_JUMP_SPEED");

}
